import torch
import torch.nn as nn
import torch.optim as optim       #含多种优化功能
import torch.nn.functional as F   #含常用无参数函数
from torchvision import datasets, transforms     #数据集接口、数据预处理
from torch.utils.data import DataLoader          #加载数据

#定义LeNet网络结构
class LeNet(nn.Module):
    def __init__(self):
        super(LeNet, self).__init__()
        self.conv1 = nn.Conv2d(1, 6, kernel_size=5, stride=1, padding=2)     #第一层卷积：输入1通道，输出6通道，卷积核5x5;提取边缘、角度等特征
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5)                         #第二层卷积：输入6通道，输出16通道；提取更复杂/局部特征
        # 全连接层，实现分类决策
        self.fc1 = nn.Linear(16 * 5 * 5, 120)
        self.fc2 = nn.Linear(120, 84)
        self.fc3 = nn.Linear(84, 10)

    def forward(self, x):                        #输入：x.shape = [64,1,28,28]
        x = F.relu(self.conv1(x))                #x.shape = [64,6,28,28]
        x = F.avg_pool2d(x, 2)         #x.shape = [64,6,14,14]  平均池化，尺寸减半
        x = F.relu(self.conv2(x))                #x.shape = [64,16,10,10]
        x = F.avg_pool2d(x, 2)         #x.shape = [64,16,5,5]  平均池化，尺寸减半
        x = x.view(-1, 16 * 5 * 5)               #x.shape = [64,400]      展平  -1表示自动计算，保持batch_size不变
        x = F.relu(self.fc1(x))                  #x.shape = [64,120]
        x = F.relu(self.fc2(x))                  #          [64,84]
        x = self.fc3(x)                          #          [64,10]
        return x


#加载 MNIST 数据集
transform = transforms.Compose([                                #创建数据预处理通道
    transforms.ToTensor(),                                      #将数据的格式转化为torch的张量（tensor）
    transforms.Normalize((0.1307,), (0.3081,))       #标准化，并分别用MNIST数据集的统计均值和方差创建单通道元组
])

train_dataset = datasets.MNIST(root='./data', train=True, download=True, transform=transform)
test_dataset = datasets.MNIST(root='./data', train=False, download=True, transform=transform)

train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)      #加载训练集，每批处理64个数据，并在每个epoch开始时随机打乱数据顺序
test_loader = DataLoader(test_dataset, batch_size=1000, shuffle=False)     #加载测试集，只用于评估，可以大批量处理，不打乱数据顺序


#定义训练设备、模型、损失函数与优化器
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")      #设置训练设备（GPU）
model = LeNet().to(device)                                                 #定义模型并转移到训练设备
criterion = nn.CrossEntropyLoss()                                          #定义损失函数为交叉熵（内部使用LogSoftmax + NLLLoss，适用多分类）
optimizer = optim.Adam(model.parameters(), lr=0.001)         #model.parameters()获取模型中所有需要训练的参数并返回包含这些参数的生成器

#训练模型
num_epochs = 5
for epoch in range(num_epochs):
    model.train()
    running_loss = 0.0
    for images, labels in train_loader:      #train_loader是一个DataLoader对象，包含训练集的图像和标签，直接解包创建images和labels
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()                #清空梯度，要在每批次最开始时就进行
        outputs = model(images)              #模型预测输出（前向传播）
        loss = criterion(outputs, labels)    #输入预测值和真实值计算损失
        loss.backward()                      #反向传播，计算参数梯度
        optimizer.step()                     #完成Adam复杂的参数更新
        running_loss += loss.item()          #.item()提取loss张量的数值
    print(f"Epoch [{epoch+1}/{num_epochs}], Loss: {running_loss/len(train_loader):.4f}")


#测试模型
model.eval()
correct = 0
total = 0
with torch.no_grad():                                         #禁用梯度，节省内存
    for images, labels in test_loader:
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        _, predicted = torch.max(outputs.data, 1)             #获取最大值的下标（即判断类别），_表示不关心最大值本身
        total += labels.size(0)                               #size(0)表示获取张量labels第0维的大小，即batch_size
        correct += (predicted == labels).sum().item()         #统计predicted和labels中相同的个数并提取数值，和correct累加

accuracy = 100 * correct / total
print(f"测试集准确率: {accuracy:.2f}%")


#保存模型
torch.save(model.state_dict(), "lenet_mnist.pth")
print("模型已保存为 lenet_mnist.pth")
