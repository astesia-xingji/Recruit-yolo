import numpy as np
import matplotlib.pyplot as plt


#函数曲线部分----------------------------------------------------------------------------------------------
def f(x):
    return 2*x**5 + x**4 - 11*x**3 + 7*x**2 + 2*x

def df(x):
    return 10*x**4 + 4*x**3 - 33*x**2 + 14*x + 2

#生成绘图点
x_vals = np.linspace(-0.5, 1.5, 400) #x轴范围，包含400个均匀点的列表
y_vals = f(x_vals)

# 随机初始点
#np.random.seed(40)    #设置种子，便于复现
x = np.random.uniform(-0.5, 1.5)   #随机抽取一个梯度下降的初始点
lr = 0.005    #学习率
steps = 100   #迭代次数
x_history = [x]    #记录初始x,y
y_history = [f(x)]

#递归主体
for i in range(steps):
    grad = df(x)
    x = x - lr * grad
    x_history.append(x)   #在列表中存储每次的x,y
    y_history.append(f(x))

#绘图
plt.figure(figsize=(8,6))      #图形尺寸
plt.plot(x_vals, y_vals, label='y = 2x⁵ + x⁴ - 11x³ + 7x² + 2x', color='blue')
plt.scatter(x_history, y_history, color='red', s=15, label='梯度下降路径')   #绘制梯度下降的离散点
plt.plot(x_history, y_history, color='white', linestyle='--', alpha=0.6)  #红色，虚线，不透明度为0.6
plt.title('函数曲线与梯度下降收敛过程')
plt.xlabel('x')   #两轴标签
plt.ylabel('y')
plt.ylim(-1,2) #y轴范围
plt.legend()      #自动收集所有带label的图形，生成图例
plt.grid(True)   #显示网格
plt.show()

print(f"收敛点 x ≈ {x:.4f}, y ≈ {f(x):.4f}")



#损失函数部分（均方误差损失函数）------------------------------------------------------------------------------------
# 生成训练数据
x_t= np.linspace(-0.5, 1.5, 200)     #x_t即x_train
y_u = 2 * x_t**5 + x_t**4 - 11 * x_t**3 + 7 * x_t**2 + 2 * x_t    #y_u即y_true

# 初始化参数
np.random.seed(0)
a, b, c, d, e = np.random.randn(5)
lr1 = 0.0005       #使用更小的学习率，减少4、5高次项的影响（每个参数的梯度都被放大很多）
epochs = 2000
losses = []         #损失列表

for _ in range(epochs):
    # 预测值
    y_pred = a * x_t**5 + b * x_t**4 + c * x_t**3 + d * x_t**2 + e * x_t     #预测函数

    # 计算损失
    loss = np.mean((y_pred - y_u) ** 2)    #均方误差损失函数，mean为求均值
    losses.append(loss)         #记录损失值

    # 计算梯度，求损失函数（MSE）对各参数的偏导，mean是原损失函数就有的
    da = np.mean(2 * (y_pred - y_u) * x_t**5)
    db = np.mean(2 * (y_pred - y_u) * x_t**4)
    dc = np.mean(2 * (y_pred - y_u) * x_t**3)
    dd = np.mean(2 * (y_pred - y_u) * x_t**2)
    de = np.mean(2 * (y_pred - y_u) * x_t)

    # 参数更新
    a -= lr1 * da
    b -= lr1 * db
    c -= lr1 * dc
    d -= lr1 * dd
    e -= lr1 * de


# 绘制损失函数曲线
plt.figure(figsize=(8, 5))
plt.plot(losses,color='blue')
plt.title('MSE')
plt.xlabel('epochs')
plt.ylabel('MSE_loss')
plt.grid(True)
plt.show()
print(f"拟合结果:")
print(f"a = {a:.4f}, b = {b:.4f}, c = {c:.4f}, d = {d:.4f}, e = {e:.4f}")